# app/agent.py

from google.adk.agents import Agent
import json
import base64

# --- Internal Tools for the Social Media & Citizen Report Agent ---

def analyze_sentiment_and_intent(text_content: str) -> dict:
    """
    Analyzes the sentiment and intent of text from social media or citizen reports.
    This tool performs part of the sentiment analysis and actionable intelligence extraction.
    """
    print(f"DEBUG: Analyzing sentiment and intent for text: '{text_content[:50]}...'")
    lower_text = text_content.lower()
    sentiment = "neutral"
    intent = "information"

    if "fire" in lower_text or "blast" in lower_text or "accident" in lower_text or "emergency" in lower_text or "stampede" in lower_text or "chaos" in lower_text or "critical" in lower_text:
        sentiment = "negative"
        intent = "emergency_alert"
    if "mob" in lower_text or "protest" in lower_text or "riot" in lower_text:
        sentiment = "negative"
        intent = "public_disorder_alert"
    if "power outage" in lower_text or "water issue" in lower_text:
        sentiment = "negative"
        intent = "utility_issue"
    if "suspicious" in lower_text or "strange person" in lower_text:
        sentiment = "negative"
        intent = "suspicious_activity"
    if "help" in lower_text or "urgent" in lower_text or "need assistance" in lower_text:
        intent = "request_for_help"
    if "good work" in lower_text or "thank you" in lower_text:
        sentiment = "positive"
        intent = "feedback"
    
    # New: RCB celebration / crowd monitoring
    if "rcb trophy" in lower_text or "rcb celebration" in lower_text:
        sentiment = "positive"
        intent = "event_monitoring"
    if "metro is full" in lower_text or "crowded" in lower_text or "packed" in lower_text or "choked" in lower_text:
        sentiment = "negative"
        if intent == "information" or intent == "event_monitoring":
            intent = "crowd_traffic_concern" # More specific intent for this scenario

    return {"sentiment": sentiment, "intent": intent}

def extract_keywords_and_entities(text_content: str) -> dict:
    """
    Extracts keywords and entities (like locations, specific concerns) from text.
    This supports identifying keywords related to incidents and actionable intelligence.
    """
    print(f"DEBUG: Extracting keywords and entities for text: '{text_content[:50]}...'")
    lower_text = text_content.lower()
    keywords = set()
    entities = {}

    # Keywords extraction
    keywords.update([
        "fire", "accident", "blast", "mob", "protest", "power outage", "water issue",
        "crime", "theft", "robbery", "suspicious activity", "chaos", "stampede",
        "rcb match", "stadium", "cricket match", "rcb trophy", "rcb celebration",
        "metro full", "crowded", "packed", "choked", "traffic", "matchday"
    ])
    keywords = [k for k in keywords if k in lower_text] # Filter to only present keywords

    # Entity (Location) extraction for Bengaluru [cite: current-location]
    # Prioritize specific locations
    if "chinnaswamy stadium" in lower_text or "rcb match" in lower_text or "cricket match" in lower_text:
        entities["location"] = "M. Chinnaswamy Stadium, Bengaluru, Karnataka, India"
        entities["event_venue"] = "M. Chinnaswamy Stadium"
    elif "majestic station" in lower_text or "metro" in lower_text:
        entities["location"] = entities.get("location", "Majestic Metro Station, Bengaluru, Karnataka, India")
        entities["transport_mode"] = "Metro"
    elif "brigade road" in lower_text: entities["location"] = "Brigade Road, Bengaluru, Karnataka, India"
    elif "mg road" in lower_text: entities["location"] = "MG Road, Bengaluru, Karnataka, India"
    elif "koramangala" in lower_text: entities["location"] = "Koramangala, Bengaluru, Karnataka, India"
    elif "indiranagar" in lower_text: entities["location"] = "Indiranagar, Bengaluru, Karnataka, India"
    elif "peenya" in lower_text: entities["location"] = "Peenya, Bengaluru, Karnataka, India"
    elif "malleshwaram" in lower_text: entities["location"] = "Malleshwaram, Bengaluru, Karnataka, India"
    elif "jp nagar" in lower_text: entities["location"] = "JP Nagar, Bengaluru, Karnataka, India"
    elif "town hall" in lower_text: entities["location"] = "Town Hall, Bengaluru, Karnataka, India"
    elif "outer ring road" in lower_text: entities["location"] = "Outer Ring Road, Bengaluru, Karnataka, India"
    elif "namma bengaluru" in lower_text or "bangalore" in lower_text or "bengaluru" in lower_text: 
        entities["location"] = entities.get("location", "Bengaluru, Karnataka, India") # Default if no specific location
    else: entities["location"] = "Location Unknown (within Bengaluru, Karnataka, India)"

    # Other entities
    if "factory" in lower_text: entities["premise_type"] = "factory"
    if "school" in lower_text: entities["premise_type"] = "school"
    if "hospital" in lower_text: entities["premise_type"] = "hospital"
    
    if "rcb trophy" in lower_text or "rcb celebration" in lower_text:
        entities["event_type"] = "RCB Victory Celebration"
    if "3 hours early" in lower_text or "3 hours before" in lower_text:
        entities["time_context"] = "3 hours before event"

    return {"keywords": list(keywords), "entities": entities}

def process_image_report(base64_image_data: str) -> dict:
    """
    Processes a base64 encoded image from a citizen report or social media.
    This supports 'Multimodal Fusion (Text/Image)' [cite: none] and helps extract actionable intelligence.
    In a real system, this would use Gemini Vision API.
    """
    print(f"DEBUG: Processing image data (base64 length: {len(base64_image_data)})...")
    try:
        if "fire_image_content_sim" in base64_image_data:
            return {"visual_incident": "Fire Detected", "visual_severity": "High", "visual_objects": ["fire", "smoke", "building"]}
        elif "mob_image_content_sim" in base64_image_data:
            return {"visual_incident": "Crowd Gathering", "visual_severity": "Medium", "visual_objects": ["crowd", "people", "protest signs"]}
        else:
            return {"visual_incident": "Unidentified/Safe", "visual_severity": "Low", "visual_objects": []}
    except Exception as e:
        print(f"ERROR: Failed to process image data: {e}")
        return {"visual_incident": "Image Processing Error", "visual_severity": "Unknown"}


# --- Main Processing Function for the Agent ---
def process_social_media_or_citizen_report(
    report_text: str = "",
    report_image_b64: str = "",
    report_source: str = "Social Media"
) -> str:
    """
    Monitors social media and citizen reports for public safety concerns and actionable intelligence.
    Processes both text and optional image inputs, analyzes sentiment, extracts entities,
    and formats relevant information for Pub/Sub and Firestore, contributing to Community Intelligence.
    """
    print(f"DEBUG: Processing report from {report_source}. Text: '{report_text[:100] if report_text else 'N/A'}' Image: {bool(report_image_b64)}")

    combined_intelligence = {
        "status": "success",
        "source_type": report_source,
        "original_text": report_text,
        "sentiment": "neutral",
        "intent": "information",
        "keywords": [],
        "entities": {},
        "visual_analysis": {},
        "public_safety_concern": False,
        "actionable_intelligence": None,
        "credibility_score": 0.7
    }

    if report_text:
        sentiment_intent = analyze_sentiment_and_intent(report_text)
        combined_intelligence.update(sentiment_intent)

        keywords_entities = extract_keywords_and_entities(report_text)
        combined_intelligence["keywords"].extend(keywords_entities["keywords"])
        combined_intelligence["entities"].update(keywords_entities["entities"])
    
    if report_image_b64:
        image_analysis_result = process_image_report(report_image_b64)
        combined_intelligence["visual_analysis"] = image_analysis_result
        if image_analysis_result.get("visual_incident") == "Fire Detected" and combined_intelligence["intent"] != "emergency_alert":
            combined_intelligence["intent"] = "emergency_alert"
            combined_intelligence["public_safety_concern"] = True
            combined_intelligence["sentiment"] = "negative"
        if image_analysis_result.get("visual_incident") == "Crowd Gathering" and combined_intelligence["intent"] != "public_disorder_alert":
            combined_intelligence["intent"] = "public_disorder_alert"
            combined_intelligence["public_safety_concern"] = True
            combined_intelligence["sentiment"] = "negative"

    # Determine if it's a public safety concern and actionable intelligence
    # Added 'crowd_traffic_concern' and 'event_monitoring' to trigger public safety concern
    if combined_intelligence["intent"] in ["emergency_alert", "public_disorder_alert", "suspicious_activity", "request_for_help", "utility_issue", "crowd_traffic_concern", "event_monitoring"]:
        combined_intelligence["public_safety_concern"] = True
        
        incident_type_output = combined_intelligence["intent"].replace('_alert', '').replace('_', ' ').title()
        if combined_intelligence["intent"] == "crowd_traffic_concern":
            incident_type_output = "Crowd & Traffic Congestion"
        elif combined_intelligence["intent"] == "event_monitoring":
            incident_type_output = "Event Crowd Monitoring" # For proactive monitoring

        severity_output = "High" if combined_intelligence["sentiment"] == "negative" else "Medium"
        # Elevate severity for critical keywords or early warning signs of chaos
        if "stampede" in combined_intelligence["keywords"] or "chaos" in combined_intelligence["keywords"]:
            severity_output = "Critical"
        elif ("crowded" in combined_intelligence["keywords"] or "packed" in combined_intelligence["keywords"] or "choked" in combined_intelligence["keywords"]) and \
             ("rcb match" in combined_intelligence["keywords"] or "stadium" in combined_intelligence["keywords"]) and \
             ("3 hours early" in combined_intelligence["entities"].get("time_context", "")):
            severity_output = "High" # Elevated severity for early, significant crowd/traffic build-up
            if "anomalies" not in combined_intelligence:
                combined_intelligence["anomalies"] = []
            combined_intelligence["anomalies"].append("significant pre-event crowd/traffic build-up")


        summary_output = f"{report_source} report: {report_text[:100] if report_text else 'Visual Incident'}. Sentiment: {combined_intelligence['sentiment']}"
        if "event_type" in combined_intelligence["entities"]:
            summary_output = f"{report_source} report: {combined_intelligence['entities']['event_type']} - {report_text[:100] if report_text else 'Visual Incident'}. Sentiment: {combined_intelligence['sentiment']}"


        combined_intelligence["actionable_intelligence"] = {
            "incident_type": incident_type_output,
            "severity": severity_output,
            "location": combined_intelligence["entities"].get("location", "Unknown"),
            "description": summary_output,
            "keywords": combined_intelligence["keywords"], # Include keywords for more context
            "entities": combined_intelligence["entities"], # Include all extracted entities
            "anomalies": combined_intelligence.get("anomalies", []) # Pass anomalies
        }
        if combined_intelligence["visual_analysis"]:
            combined_intelligence["actionable_intelligence"]["visual_summary"] = combined_intelligence["visual_analysis"].get("visual_incident")
            

    # Simulate publishing to Pub/Sub and writing to Firestore
    print(f"DEBUG: Simulating Pub/Sub publish and Firestore write for: {combined_intelligence['actionable_intelligence']}")

    if combined_intelligence["public_safety_concern"] and combined_intelligence["actionable_intelligence"]:
        orchestration_output = {
            "incident_source": report_source,
            "incident_type": combined_intelligence["actionable_intelligence"]["incident_type"],
            "severity": combined_intelligence["actionable_intelligence"]["severity"],
            "location": combined_intelligence["actionable_intelligence"]["location"],
            "description": combined_intelligence["actionable_intelligence"]["description"], # Use the more detailed description
            "keywords": combined_intelligence["actionable_intelligence"]["keywords"],
            "entities": combined_intelligence["actionable_intelligence"]["entities"],
            "anomalies": combined_intelligence["actionable_intelligence"]["anomalies"]
        }
        return json.dumps(orchestration_output)
    else:
        return json.dumps({"status": "no_concern", "message": "Report processed, no immediate public safety concern identified.", "details": combined_intelligence})


# --- Agent Definition ---
basic_agent = Agent(
    model='gemini-2.0-flash-001',
    name='Social_Media_Citizen_Report_Agent',
    description=(
        'An AI agent that continuously monitors public social media feeds and processes citizen reports '
        'from a Firebase-powered app. It identifies keywords related to incidents, analyzes '
        'sentiment, extracts actionable intelligence (e.g., "mob forming," "power outage"), '
        'and filters noise to identify credible reports. This agent contributes to Community '
        'Intelligence [cite: none] by leveraging distributed citizen insights and performs Multimodal Fusion '
        '(Text/Image) [cite: none] for comprehensive analysis.\n\n'
        '**Problem Addressed:** This agent directly tackles the problem of **fragmented data sources** '
        '(specifically social media and citizen reports) and **delayed recognition of threats** '
        'from unstructured digital information [cite: file_content_0]. It transforms raw, diverse data '
        'into **actionable intelligence**, enabling **proactive identification of emerging threats** '
        'and enhancing **situational awareness** for the Public Safety Command Center [cite: file_content_0]. '
        'By performing automated **sentiment analysis, keyword extraction, and multimodal fusion**, '
        'it augments human operators and ensures critical insights from the community are not missed [cite: file_content_0].'
    ),
    instruction=(
        'You are the Social Media & Citizen Report Agent. Your primary role is to process incoming '
        'reports, which can contain text (from social media or a citizen app) and/or optional base64 encoded images. '
        'You must analyze sentiment, extract keywords and entities, and identify actionable intelligence '
        'related to public safety concerns, including early indicators of crowd or traffic issues. '
        'If an image is provided, process it for visual insights. '
        'Your final output MUST be a structured JSON string containing identified incident details, '
        'including incident type, severity (e.g., "Medium" for early concerns, "High" for escalating, "Critical" for severe), '
        'location, a concise description, relevant keywords, extracted entities, and any detected anomalies. '
        'This output is ready to be consumed by the Central Orchestration Agent for potential emergency response triggering. '
        'If no clear public safety concern is found, output a JSON with "status": "no_concern".'
    ),
    tools=[process_social_media_or_citizen_report],
)

root_agent = basic_agent
