# app/agent.py

from google.adk.agents import Agent
import json
import datetime

# --- Internal Tools for the Predictive Policing Agent ---

def fetch_realtime_context(current_time: str, current_day: str, active_events: list = None) -> dict:
    """
    Simulates fetching real-time context from Firestore (e.g., current incident clusters, public events).
    In a real system, this would query Firestore.
    """
    print(f"DEBUG: Fetching real-time context for {current_day} at {current_time} with events: {active_events}")
    context = {
        "current_time_of_day": current_time,
        "current_day_of_week": current_day,
        "active_public_events": active_events if active_events else [],
        "recent_incidents_count": 5 # Placeholder for recent incidents
    }
    # Example: If there's an RCB match, it's a significant event
    if "RCB Match" in (event.get("name") for event in active_events) if active_events else []:
        context["recent_incidents_count"] += 10 # Simulate more recent incidents around event
    return context

def get_historical_patterns(location_context: str, time_context: str, day_context: str) -> dict:
    """
    Simulates accessing historical crime data patterns from Cloud Storage/Vertex AI.
    In a real system, this would query a data warehouse or pre-computed patterns.
    """
    print(f"DEBUG: Accessing historical patterns for {location_context} on {day_context} at {time_context}")
    patterns = {
        "crime_rate_trend": "stable",
        "common_crime_types": ["theft"],
        "historical_hotspots": []
    }
    # Simulate different historical patterns based on context
    if "MG Road" in location_context and "night" in time_context and "weekend" in day_context:
        patterns["crime_rate_trend"] = "high_theft_spike"
        patterns["common_crime_types"].append("assault")
        patterns["historical_hotspots"].append("MG Road Commercial Area")
    if "Chinnaswamy Stadium" in location_context and "evening" in time_context and "matchday" in day_context:
        patterns["crime_rate_trend"] = "high_pickpocket_crowd_disorder"
        patterns["common_crime_types"].append("pickpocketing")
        patterns["historical_hotspots"].append("Stadium Vicinity")
    return patterns

def predict_crime_likelihood(context: dict, historical_patterns: dict) -> dict:
    """
    Simulates calling a Vertex AI deployed ML model to predict crime likelihood for areas.
    This is the core of 'Anticipatory Law Enforcement' [cite: file_content_0].
    """
    print(f"DEBUG: Predicting crime likelihood using context and historical patterns.")
    likelihood = {
        "overall_risk": "Low",
        "hotspots": [],
        "predicted_crime_types": []
    }

    current_time = context["current_time_of_day"]
    current_day = context["current_day_of_week"]
    active_events = context["active_public_events"]
    recent_incidents = context["recent_incidents_count"]
    
    # Simple rule-based prediction for demonstration
    if historical_patterns["crime_rate_trend"] == "high_theft_spike":
        likelihood["overall_risk"] = "Medium"
        likelihood["predicted_crime_types"].append("Theft")
        likelihood["hotspots"].extend(historical_patterns["historical_hotspots"])
    
    if "RCB Match" in (event.get("name") for event in active_events) and recent_incidents > 10:
        likelihood["overall_risk"] = "High"
        likelihood["predicted_crime_types"].append("Pickpocketing")
        likelihood["predicted_crime_types"].append("Crowd Disorder")
        likelihood["hotspots"].append("Stadium Gates")
        if "evening" in current_time:
            likelihood["overall_risk"] = "Critical" # Escalating risk
            likelihood["predicted_crime_types"].append("Minor Assault")

    # If no specific hotspots from historical, default to general area
    if not likelihood["hotspots"] and context["active_public_events"]:
        likelihood["hotspots"].append(f"Area around {context['active_public_events'][0].get('location', 'event venue')}")

    return likelihood

def generate_patrol_suggestions(crime_predictions: dict) -> list:
    """
    Generates actionable proactive patrol suggestions based on crime predictions.
    This is part of 'Data-Driven Proactivity' [cite: file_content_0].
    """
    print(f"DEBUG: Generating patrol suggestions based on predictions.")
    suggestions = []
    
    risk = crime_predictions["overall_risk"]
    hotspots = crime_predictions["hotspots"]
    predicted_types = crime_predictions["predicted_crime_types"]

    if risk == "Critical":
        suggestions.append(f"IMMEDIATE HIGH-VISIBILITY PATROL: Deploy multiple units to {', '.join(hotspots)} for {', '.join(predicted_types)} prevention.")
        suggestions.append("Consider deploying plainclothes officers for pickpocketing prevention.")
    elif risk == "High":
        suggestions.append(f"INCREASED PATROL: Assign additional patrols to {', '.join(hotspots)} focusing on {', '.join(predicted_types)}.")
        suggestions.append("Monitor CCTV feeds closely in identified hotspots.")
    elif risk == "Medium":
        suggestions.append(f"ROUTINE PATROL ENHANCEMENT: Ensure regular patrols cover {', '.join(hotspots)} during {predicted_types if predicted_types else 'general crime'} high-risk periods.")
    else:
        suggestions.append("Maintain standard patrol levels. Monitor for new intelligence.")
    
    return suggestions

# --- Main Processing Function for the Agent ---
def predict_and_suggest_patrols(
    location_context: str,
    time_of_day: str, # e.g., "morning", "afternoon", "evening", "night"
    day_of_week: str, # e.g., "weekday", "weekend", "matchday"
    active_events: list = None # e.g., [{"name": "RCB Match", "location": "M. Chinnaswamy Stadium"}]
) -> str:
    """
    Predicts crime hotspots and generates proactive patrol suggestions based on historical data
    and real-time context. The output is stored in Firestore.
    """
    print(f"DEBUG: Initiating crime prediction for {location_context} on {day_of_week} at {time_of_day}.")

    # 1. Fetch Real-time Context
    context = fetch_realtime_context(time_of_day, day_of_week, active_events)

    # 2. Get Historical Patterns (simulated based on location/time)
    historical_patterns = get_historical_patterns(location_context, time_of_day, day_of_week)

    # 3. Predict Crime Likelihood
    crime_predictions = predict_crime_likelihood(context, historical_patterns)

    # 4. Generate Patrol Suggestions
    patrol_suggestions = generate_patrol_suggestions(crime_predictions)

    # Construct the output for Firestore
    prediction_output = {
        "timestamp": datetime.datetime.now().isoformat(),
        "predicted_location_context": location_context,
        "time_context": time_of_day,
        "day_context": day_of_week,
        "active_events": active_events,
        "overall_risk": crime_predictions["overall_risk"],
        "predicted_hotspots": crime_predictions["hotspots"],
        "predicted_crime_types": crime_predictions["predicted_crime_types"],
        "proactive_patrol_suggestions": patrol_suggestions,
        "source_agent": "Predictive Policing Agent"
    }

    # --- Conceptual Firestore Write ---
    # In a real GCP environment, this would write to a 'crime_predictions' collection:
    # db = firestore.Client(project="YOUR_GCP_PROJECT_ID")
    # doc_ref = db.collection("crime_predictions").add(prediction_output)
    # print(f"INFO: Wrote crime prediction document to Firestore: {doc_ref.id}")
    print(f"DEBUG: Simulating Firestore write to 'crime_predictions' collection: {json.dumps(prediction_output)}")

    return json.dumps(prediction_output)


# --- Agent Definition ---
basic_agent = Agent(
    model='gemini-2.0-flash-001',
    name='Predictive_Policing_Agent',
    description=(
        'An AI agent that analyzes historical crime data, demographic, weather, public events, and infrastructure data '
        'to predict crime hotspots and high-risk areas. It generates proactive patrol suggestions, enabling '
        'Anticipatory Law Enforcement [cite: file_content_0] and Data-Driven Proactivity [cite: file_content_0]. '
        'It continuously learns and improves prediction accuracy (via MLOps pipelines not directly in this agent). '
        'Outputs are stored in Firestore for consumption by other agents and the Public Safety Command Center.'
    ),
    instruction=(
        'You are the Predictive Policing Agent. Your role is to take current contextual information '
        '(location, time, day, active events) and, by leveraging simulated historical data and ML models, '
        'predict crime likelihood and generate actionable proactive patrol suggestions. '
        'Your final output MUST be a structured JSON string containing these predictions and suggestions, '
        'which will be stored in Firestore for other agents and human operators. '
        'Do NOT ask for additional information; your processing is based on the given input parameters.'
    ),
    tools=[predict_and_suggest_patrols], # The main tool for this agent
)

root_agent = basic_agent
